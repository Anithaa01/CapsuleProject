package com.learning.taskMaintenance.entity;

import java.io.Serializable;

import javax.persistence.Id;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

@SuppressWarnings("serial")
@Document(collection = "parent_entity")
public class ParentTaskEntity  implements Serializable {

	 @Id
	public ObjectId _id;
	private int parentId;
	private String parentTask;
	
	public ParentTaskEntity() {
		// TODO Auto-generated constructor stub
	}
	
	public ParentTaskEntity(int parentId, String parentTask) {
		this.parentId = parentId;
		this.parentTask = parentTask;
	}

	/**
	 * @return the _id
	 */
	public ObjectId get_id() {
		return _id;
	}

	/**
	 * @param _id the _id to set
	 */
	public void set_id(ObjectId _id) {
		this._id = _id;
	}

	/**
	 * @return the parentId
	 */
	public int getParentId() {
		return parentId;
	}

	/**
	 * @param parentId the parentId to set
	 */
	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

	/**
	 * @return the parentTask
	 */
	public String getParentTask() {
		return parentTask;
	}

	/**
	 * @param parentTask the parentTask to set
	 */
	public void setParentTask(String parentTask) {
		this.parentTask = parentTask;
	}
	
	
	
}
