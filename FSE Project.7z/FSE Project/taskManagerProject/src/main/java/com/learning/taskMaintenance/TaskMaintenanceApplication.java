package com.learning.taskMaintenance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskMaintenanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskMaintenanceApplication.class, args);
	}

}
