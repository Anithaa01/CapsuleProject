package com.learning.taskMaintenance.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.learning.taskMaintenance.Exception.CustomTaskException;
import com.learning.taskMaintenance.model.StatusDTO;
import com.learning.taskMaintenance.model.TaskManagerDTO;
import com.learning.taskMaintenance.service.ITaskManagerService;

@CrossOrigin
@SuppressWarnings({ "unchecked", "rawtypes" })
@RestController
@RequestMapping("/task-manager")
public class TaskManagerController {

	private static Logger logger = LoggerFactory.getLogger(TaskManagerController.class);

	@Autowired
	private ITaskManagerService taskManagerService;
	
	@RequestMapping(value = "/task", method = RequestMethod.GET)
	public ResponseEntity<List<TaskManagerDTO>> fetchAllTasks() {
		List<TaskManagerDTO> tasks = taskManagerService.fetchData();
		if (tasks.isEmpty()) {
			logger.debug("TaskManager Controller - no data in fetch details");
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		logger.debug("TaskManager Controller - Data fetch process completed");
		System.out.println(tasks.toString());
		return new ResponseEntity<List<TaskManagerDTO>>(tasks, HttpStatus.OK);
	}

	@RequestMapping(value = "/task/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> fetchTaskById(@PathVariable("id") int id) {
		TaskManagerDTO task = taskManagerService.findById(id);
		if (task == null) {
			logger.debug("TaskManager Controller - no data in fetch a single details");
			return new ResponseEntity(new CustomTaskException("Task with id " + id + " not found"),
					HttpStatus.NOT_FOUND);
		}
		logger.debug("TaskManager Controller - Data fetch process completed");
		return new ResponseEntity<TaskManagerDTO>(task, HttpStatus.OK);
	}

	@RequestMapping(value = "/deleteTask", method = RequestMethod.POST)
	public ResponseEntity<StatusDTO> deleteTask(@RequestBody TaskManagerDTO taskManagerDTO) {
		StatusDTO task = taskManagerService.deleteData(taskManagerDTO);
		if (task == null) {
			logger.debug("TaskManager Controller - no data deleted");
			return new ResponseEntity(
					new CustomTaskException("Task with id " + taskManagerDTO.getTaskId() + " not found"),
					HttpStatus.NOT_FOUND);
		}
		logger.debug("TaskManager Controller - Data delete process completed");
		return new ResponseEntity<StatusDTO>(task, HttpStatus.OK);
	}

	@RequestMapping(value = "/editTask", method = RequestMethod.POST)
	public ResponseEntity<StatusDTO> editTask(@RequestBody TaskManagerDTO taskManagerDTO) {
		StatusDTO task = taskManagerService.editData(taskManagerDTO);
		if (task == null) {
			logger.debug("TaskManager Controller - no data edited");
			return new ResponseEntity(
					new CustomTaskException("Task with id " + taskManagerDTO.getTaskId() + " not found"),
					HttpStatus.NOT_FOUND);
		}
		logger.debug("TaskManager Controller - Data edit process completed");
		return new ResponseEntity<StatusDTO>(task, HttpStatus.OK);
	}

	@RequestMapping(value = "/saveTask", method = RequestMethod.POST)
	public ResponseEntity<StatusDTO> saveTask(@RequestBody TaskManagerDTO taskManagerDTO) {
		StatusDTO task = taskManagerService.saveData(taskManagerDTO);
		if (task == null) {
			logger.debug("TaskManager Controller - no data saved");
			return new ResponseEntity(
					new CustomTaskException("Task with id " + taskManagerDTO.getTaskId() + " not found"),
					HttpStatus.NOT_FOUND);
		}
		logger.debug("TaskManager Controller - Data save process completed");
		return new ResponseEntity<StatusDTO>(task, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/endTask", method = RequestMethod.POST)
	public ResponseEntity<StatusDTO> endTask(@RequestBody TaskManagerDTO taskManagerDTO) {
		StatusDTO task = taskManagerService.endTask(taskManagerDTO);
		if (task == null) {
			logger.debug("TaskManager Controller - no data saved");
			return new ResponseEntity(
					new CustomTaskException("Task with id " + taskManagerDTO.getTaskId() + " not found"),
					HttpStatus.NOT_FOUND);
		}
		logger.debug("TaskManager Controller - Data end process completed");
		return new ResponseEntity<StatusDTO>(task, HttpStatus.OK);
	}
	
}
