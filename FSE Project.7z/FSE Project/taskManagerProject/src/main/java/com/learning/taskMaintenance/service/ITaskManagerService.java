package com.learning.taskMaintenance.service;

import java.util.List;

import com.learning.taskMaintenance.model.StatusDTO;
import com.learning.taskMaintenance.model.TaskManagerDTO;

public interface ITaskManagerService {
	
	public List<TaskManagerDTO> fetchData();
	
	public TaskManagerDTO findById(int id);
	
	public StatusDTO deleteData(TaskManagerDTO taskManager);
	
	public StatusDTO editData(TaskManagerDTO taskManager);
	
	public StatusDTO saveData(TaskManagerDTO taskManager);
	
	public StatusDTO endTask(TaskManagerDTO taskManager);
	
}
