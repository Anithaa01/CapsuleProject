package com.learning.taskMaintenance.repository;

import java.io.Serializable;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.learning.taskMaintenance.entity.TaskEntity;

public interface TaskRepository extends MongoRepository<TaskEntity, Serializable>{

	TaskEntity findByTaskId(int taskId);
}

