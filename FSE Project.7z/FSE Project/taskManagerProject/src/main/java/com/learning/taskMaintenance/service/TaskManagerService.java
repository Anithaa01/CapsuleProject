package com.learning.taskMaintenance.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.learning.taskMaintenance.custom.repository.TaskManagerRepository;
import com.learning.taskMaintenance.entity.ParentTaskEntity;
import com.learning.taskMaintenance.entity.TaskEntity;
import com.learning.taskMaintenance.model.StatusDTO;
import com.learning.taskMaintenance.model.TaskManagerDTO;
import com.learning.taskMaintenance.repository.ParentTaskRepository;
import com.learning.taskMaintenance.repository.TaskRepository;

@Component
public class TaskManagerService implements ITaskManagerService {

	private static Logger logger = LoggerFactory.getLogger(TaskManagerService.class);

	@Autowired
	private TaskRepository taskRepository;

	@Autowired
	private ParentTaskRepository parentTaskRepository;

	@Autowired
	private TaskManagerRepository taskManagerRepository;

	@Override
	public List<TaskManagerDTO> fetchData() {
		logger.debug("Task Manager Service - begining of fetchData..");
		List<TaskManagerDTO> taskManagerList = new ArrayList<TaskManagerDTO>();

		List<TaskEntity> taskEoList = taskRepository.findAll();

		for (TaskEntity taskEo : taskEoList) {
			TaskManagerDTO taskManager = new TaskManagerDTO();
			ParentTaskEntity parentEo = parentTaskRepository.findByParentId(taskEo.getParentId());
			if (parentEo != null) {
				taskManager.setParentTask(parentEo.getParentTask());
			}
			taskManager.setTaskId(taskEo.getTaskId());
			taskManager.setTask(taskEo.getTask());
			taskManager.setPriority(taskEo.getPriority());
			taskManager.setStartDate(taskEo.getStartDate().toString());
			taskManager.setEndDate(taskEo.getEndDate().toString());
			taskManager.setActiveFlag(taskEo.getActiveFlag());
			taskManagerList.add(taskManager);
		}
		logger.debug("Task Manager Service - end of fetchData..");
		return taskManagerList;
	}

	@Override
	public TaskManagerDTO findById(int id) {
		logger.debug("Task Manager Service - begining of fetchData..");
		TaskManagerDTO tasks = new TaskManagerDTO();
		TaskEntity taskEo = taskRepository.findByTaskId(id);
		ParentTaskEntity parentEo = parentTaskRepository.findByParentId(taskEo.getParentId());
		if (parentEo != null) {
			tasks.setParentTask(parentEo.getParentTask());
		}
		tasks.setTaskId(taskEo.getTaskId());
		tasks.setTask(taskEo.getTask());
		tasks.setPriority(taskEo.getPriority());
		tasks.setStartDate(taskEo.getStartDate().toString());
		tasks.setEndDate(taskEo.getEndDate().toString());
		logger.debug("Task Manager Service - end of fetchData..");
		return tasks;
	}

	@Override
	public StatusDTO endTask(TaskManagerDTO taskManager) {
		logger.debug("Task Manager Service - begining of endTask..");
		StatusDTO status = null;
		try {
			TaskEntity taskEo = taskRepository.findByTaskId(taskManager.getTaskId());
			taskEo.setActiveFlag("N");
			taskRepository.save(taskEo);
			status = new StatusDTO("Success", "Successfully ended the task");
		} catch (Exception e) {
			status = new StatusDTO("ERROR", "Error occured while ending the task");
		}
		logger.debug("Task Manager Service - end of endTask..");
		return status;
	}

	@Override
	public StatusDTO deleteData(TaskManagerDTO taskManager) {
		logger.debug("Task Manager Service - begining of deleteData..");
		StatusDTO status = null;
		try {
			TaskEntity taskEo = taskRepository.findByTaskId(taskManager.getTaskId());
			taskRepository.delete(taskEo);
			status = new StatusDTO("Success", "success");
		} catch (Exception e) {
			status = new StatusDTO("ERROR", "Error occured while saving the data");
		}
		logger.debug("Task Manager Service - end of deleteData..");
		return status;
	}

	@Override
	@Transactional
	public StatusDTO editData(TaskManagerDTO taskManager) {
		logger.debug("Task Manager Service - begining of editData..");
		StatusDTO status = null;
		ParentTaskEntity parentTaskEntity = null;
		ParentTaskEntity parentTaskEo = null;
		try {
			TaskEntity taskEo = taskRepository.findByTaskId(taskManager.getTaskId());
			if (taskEo != null) {
				parentTaskEntity = taskManagerRepository.getParentEntityByName(taskManager.getParentTask());
				if (parentTaskEntity == null) {
					parentTaskEntity = taskManagerRepository.getParentEntity();
					parentTaskEo = new ParentTaskEntity(parentTaskEntity.getParentId() + 1,
							taskManager.getParentTask());
					parentTaskRepository.save(parentTaskEo);
					taskEo.setParentId(parentTaskEo.getParentId());
				}

				if(!validateDate(taskManager.getStartDate())) {
					taskEo.setStartDate(formatDate(taskManager.getStartDate()));
				} else {
					taskEo.setStartDate(taskManager.getStartDate());
				}
				if(!validateDate(taskManager.getEndDate())) {
					taskEo.setEndDate(formatDate(taskManager.getEndDate()));
				} else {
					taskEo.setEndDate(taskManager.getEndDate());
				}
							
				taskEo.setPriority(taskManager.getPriority());
				taskEo.setTask(taskManager.getTask());
				taskRepository.save(taskEo);
				status = new StatusDTO("SUCCESS", "Edited the data successfully");
			}
		} catch (Exception e) {
			status = new StatusDTO("ERROR", "Error occured while editing the data");
		}
		logger.debug("Task Manager Service - end of editData..");
		return status;
	}

	@Override
	@Transactional
	public StatusDTO saveData(TaskManagerDTO taskManager) {
		logger.debug("Task Manager Service - begining of saveData..");
		StatusDTO status = null;
		ParentTaskEntity parentTaskEntity = null;
		try {
			TaskEntity taskEo = new TaskEntity();
			TaskEntity taskEntity = taskManagerRepository.getTaskEntity();
			if (taskEntity == null) {
				taskEo.setTaskId(0);
				taskEntity = new TaskEntity();
				taskEntity.setTaskId(0);
			}
			if (taskManager.getParentTask() != null) {
				parentTaskEntity = taskManagerRepository.getParentEntityByName(taskManager.getParentTask());
				
				if (parentTaskEntity != null) {

					taskEo = new TaskEntity(taskEntity.getTaskId() + 1, parentTaskEntity.getParentId(),
							taskManager.getTask(), formatDate(taskManager.getStartDate()),
							formatDate(taskManager.getEndDate()), taskManager.getPriority(), "Y");
					taskRepository.save(taskEo);

				} else {
					parentTaskEntity = taskManagerRepository.getParentEntity();
					
					if (parentTaskEntity == null) {
						parentTaskEntity = new ParentTaskEntity();
						parentTaskEntity.setParentId(0);
					}
					
					ParentTaskEntity parentEo = new ParentTaskEntity(parentTaskEntity.getParentId() + 1,
							taskManager.getParentTask());
					parentTaskRepository.save(parentEo);

					ParentTaskEntity parentTaskEntity1 = taskManagerRepository
							.getParentEntityByName(taskManager.getParentTask());
					taskEo = new TaskEntity(taskEntity.getTaskId() + 1, parentTaskEntity1.getParentId(),
							taskManager.getTask(), formatDate(taskManager.getStartDate()),
							formatDate(taskManager.getEndDate()), taskManager.getPriority(), "Y");
					taskRepository.save(taskEo);
				}

			} else {
				taskEo = new TaskEntity(taskEntity.getTaskId() + 1, 0, taskManager.getTask(),
						formatDate(taskManager.getStartDate()), formatDate(taskManager.getEndDate()),
						taskManager.getPriority(), "Y");
				taskRepository.save(taskEo);
			}
			status = new StatusDTO("SUCCESS", "Successfully saved the data");
		} catch (Exception e) {
			status = new StatusDTO("ERROR", "Error occured while saving the data");
		}
		logger.debug("Task Manager Service - end of saveData..");
		return status;
	}

	
	private String formatDate(String dateToFormat) throws ParseException{
		String[] dt = dateToFormat.split("T");
		SimpleDateFormat inSDF = new SimpleDateFormat("yyyy-mm-dd");
        SimpleDateFormat outSDF = new SimpleDateFormat("dd-mm-yyyy");
        String outDate = "";
         Date date = null;
        try {
            date = inSDF.parse(dt[0]);
            outDate = outSDF.format(date);
        } catch (Exception ex){ 
        	logger.error("Format date error..");
        }
        
        return outDate;
	}
	
	private boolean validateDate(String date){
		boolean flag = false;
		String[] newDate = date.split("-");
		if(newDate[0].length() == 2 && newDate[1].length() == 2 && newDate[2].length() == 4) {
			flag = true;
		}
		
		return flag;
	}

}
