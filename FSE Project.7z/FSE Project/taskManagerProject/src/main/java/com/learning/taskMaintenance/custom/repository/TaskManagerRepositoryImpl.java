package com.learning.taskMaintenance.custom.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.learning.taskMaintenance.entity.ParentTaskEntity;
import com.learning.taskMaintenance.entity.TaskEntity;

@Repository("taskManagerRepository")
public class TaskManagerRepositoryImpl implements TaskManagerRepository{
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Override
	public ParentTaskEntity getParentEntity() {
		Query query = new Query();
	    query.with(new Sort(Sort.Direction.DESC, "parentId"));
	    query.fields().exclude("_id");
	    return mongoTemplate.findOne(query, ParentTaskEntity.class);
	}

	@Override
	public ParentTaskEntity getParentEntityByName(String name) {
		Query query = new Query();
		query.addCriteria(Criteria.where("parentTask").is(name));		
	    return mongoTemplate.findOne(query, ParentTaskEntity.class);
	}
	
	@Override
	public TaskEntity getTaskEntity() {
		Query query = new Query();
	    query.with(new Sort(Sort.Direction.DESC, "taskId"));
	    query.fields().exclude("_id");
	    return mongoTemplate.findOne(query, TaskEntity.class);
	}
	
	@Override
	public TaskEntity getTaskEntityByName(String name) {
		Query query = new Query();
		query.addCriteria(Criteria.where("task").is(name));		
	    return mongoTemplate.findOne(query, TaskEntity.class);
	}
	
}
