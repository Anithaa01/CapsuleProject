package com.learning.taskMaintenance.custom.repository;

import java.util.List;

import com.learning.taskMaintenance.entity.ParentTaskEntity;
import com.learning.taskMaintenance.entity.TaskEntity;

public interface TaskManagerRepository {

	public ParentTaskEntity getParentEntity();
	
	public TaskEntity getTaskEntity();
	
	public ParentTaskEntity getParentEntityByName(String name);
	
	public TaskEntity getTaskEntityByName(String name);
	
}
