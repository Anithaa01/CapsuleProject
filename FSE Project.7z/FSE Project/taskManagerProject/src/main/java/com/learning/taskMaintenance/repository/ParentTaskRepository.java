package com.learning.taskMaintenance.repository;

import java.io.Serializable;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.learning.taskMaintenance.entity.ParentTaskEntity;

public interface ParentTaskRepository extends MongoRepository<ParentTaskEntity, Serializable> {

	ParentTaskEntity findByParentId(int parentId);
}
