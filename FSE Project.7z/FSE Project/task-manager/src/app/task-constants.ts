export const taskValues = Object.freeze({
    Urls : {
        addTask : '/saveTask',
        fetchTask : '/task',
        endTask : '/endTask',
        editTask: '/editTask'
    }
});