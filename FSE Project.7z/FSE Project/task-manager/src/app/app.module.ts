import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TasksComponent } from './tasks/tasks.component';
import { AddTaskComponent } from './add-task/add-task.component';
import { RangeSliderModule  } from 'ngx-range-slider';


import { BsDatepickerModule } from 'ngx-bootstrap';
import { UpdateTaskComponent } from './update-task/update-task.component';
import { HttpClientModule } from '@angular/common/http';
import {TaskService} from '../app/task.service';
import { FormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';

@NgModule({
  declarations: [
    AppComponent,
    TasksComponent,
    AddTaskComponent,
    UpdateTaskComponent
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    RangeSliderModule,
    BsDatepickerModule.forRoot(),
    FormsModule,
    ModalModule.forRoot()
  ],
  providers: [TaskService],
  bootstrap: [AppComponent],
  entryComponents: [UpdateTaskComponent]
})
export class AppModule { }
