import { Component, OnInit, Output , EventEmitter} from '@angular/core';
import { TaskService } from '../task.service';
import { TaskManager } from '../task-models';
import { BsModalRef } from 'ngx-bootstrap';
@Component({
  selector: 'app-update-task',
  templateUrl: './update-task.component.html',
  styleUrls: ['./update-task.component.css']
})
export class UpdateTaskComponent implements OnInit {

  status: TaskManager;
  
  tasks :any;
  
  constructor(public taskService : TaskService,public  bsModalRef: BsModalRef) { }

  ngOnInit() {
    this.tasks = JSON.parse(JSON.stringify(this.status));
  }

  updateTask(result) {
    console.log(result);
    this.taskService.editTask(result).subscribe(data => {
      console.log(data);
      this.taskService.updateMessage.emit(data.message);
      this.bsModalRef.hide();
    });
  }

  reset(){
    this.status = this.tasks;
  }
}
