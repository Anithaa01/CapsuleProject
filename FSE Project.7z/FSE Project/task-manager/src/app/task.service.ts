import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { taskValues } from './task-constants';
import { map, min } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
 })
export class TaskService {

    updateMessage = new EventEmitter();

    apiUrl = 'http://localhost:8080/task-manager';

    constructor(public http : HttpClient){}

    saveTask(requestData){
        return this.http.post(this.apiUrl + taskValues.Urls.addTask , requestData).pipe
         (map((data: any) => {
            return data;
          },
          (error: any) => {
            return error;
          }));
    }  


    getTask(){
        return this.http.get(this.apiUrl + taskValues.Urls.fetchTask)
        .pipe(map((resp : Response) => resp));
    }

    
    endTask(requestData){
        return this.http.post(this.apiUrl + taskValues.Urls.endTask , requestData).pipe
         (map((data: any) => {
            return data;
          },
          (error: any) => {
            return error;
          }));
    }  

    editTask(requestData){
        return this.http.post(this.apiUrl  + taskValues.Urls.editTask,requestData)
        .pipe(map((data: any) => {
            return data;
          },
          (error: any) => {
            return error;
          }));
    }
}