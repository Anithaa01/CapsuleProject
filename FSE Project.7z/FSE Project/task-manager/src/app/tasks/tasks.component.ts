import { Component, OnInit, Input } from '@angular/core';
import { TaskService } from '../task.service';
import { UpdateTaskComponent } from '../update-task/update-task.component';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';


@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})
export class TasksComponent implements OnInit {

  
  bsModalRef: BsModalRef;
  public taskResult : any ;
  
  public searchTasks = {
    
	 task : '',
	 parentTask : '',
	 startDate : '',
	 endDate : '',
	 priorityFrom : '',
	 priorityTo : ''
	 
  }

  public searchResult : any = [];

  messages : any = '';

  constructor(public taskService : TaskService, private modalService: BsModalService) { 
    this.fetch();
    
    this.taskService.updateMessage.subscribe(updateMessage => {
      this.messages = updateMessage;
      this.fetch();
    });

  }

  ngOnInit() {
    this.fetch();
    console.log(this.taskResult);
  }

  fetch() {
      this.taskService.getTask().subscribe(resp => {
        this.taskResult = resp;
        console.log(resp); 
         },
        error => { console.log(error);
        });
  }

  onEndTask(result) {
        this.taskService.endTask(result).subscribe(resp => {
          this.messages = resp.message;
          console.log(resp); 
           },
          error => {  this.messages = error.message ;console.log(error);
          });
        this.fetch();
  }

  editTask(result) {

        const initialState = { status: JSON.parse(JSON.stringify(result)) };
        this.bsModalRef = this.modalService.show(UpdateTaskComponent, { initialState });
        this.fetch();
        
  }

  searchData(searchTasks){

    var res = '';
    let queryString = [];
    for (var key in searchTasks) {
      if(searchTasks[key] !== '') {
        res = res.concat(res, ('taskData.'+key+ ' === searchTasks.'+key));
        queryString.push(res);
        res = '';
      }
    }
 // console.log(queryString);
   var searchQuery = queryString.join(' && ');

   console.log(searchQuery);
      
     this.searchResult = this.taskResult.filter(     
       taskData => {
        console.log(searchQuery);
        return searchQuery;
       } 
      ); 
      console.log(this.searchResult );

  }


  search(searchTasks) {

    this.taskResult = filter(this.taskResult, { task : searchTasks.task, parentTask : searchTasks.parentTask,
    startDate : searchTasks.startDate, endDate : searchTasks.endDate});

    function filter(arr, criteria) {
      return arr.filter(function(obj) {
        return Object.keys(criteria).every(function(c) {
          return new RegExp(criteria[c]).test(obj[c]);
        });
      });
    }

    if(searchTasks.priorityFrom !== '' && searchTasks.priorityTo !== ''){
      this.taskResult = this.taskResult.filter( taskData => 
        taskData.priority >= searchTasks.priorityFrom && taskData.priority <= searchTasks.priorityTo);
    } else if((searchTasks.priorityFrom !== '' && searchTasks.priorityTo === '') || 
      searchTasks.priorityFrom === '' && searchTasks.priorityTo !== '') {
      this.messages = "Enter proper priority range";
    }

    console.log(this.taskResult);
  }


  reset(){
    this.searchTasks = {
      task : '',
      parentTask : '',
      startDate : '',
      endDate : '',
      priorityFrom : '',
      priorityTo : ''
    }
    this.fetch();
    this.messages = '';
   }
}
