import { Component, OnInit,Input } from '@angular/core';
import { TaskService } from '../task.service';
import { TaskManager } from '../task-models';
@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {

  minDate : Date;
  public tasks = new TaskManager();
  constructor(public taskService : TaskService) { 
    this.minDate = new Date();
  }
  messages : any = '';

  ngOnInit() {

  }

  public onSave() {
      console.log(this.tasks);

      if(this.tasks.task == '' || this.tasks.startDate =='' || this.tasks.endDate == ''){

        this.messages = "Enter all the details(Task Name, Start Date and End Date)";
        return;
      }


      
      this.taskService.saveTask(this.tasks).subscribe(data =>  {
      console.log(data),
      this.messages = data.message },
      error => this.messages = error.message);
      
  }

  reset(){
   this.tasks.task = '';
   this.tasks.taskId = 0;
   this.tasks.parentTask = '';
   this.tasks.priority=0;
   this.tasks.startDate = '';
   this.tasks.endDate='';
   this.messages= '';
  }
}
