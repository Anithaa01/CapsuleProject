export class TaskManager{

    public taskId : number;
	public task : String;
	public parentTask : String;
	public startDate : string;
	public endDate : string;
	public priority : number;
	public activeFlag : String = 'Y';
}
