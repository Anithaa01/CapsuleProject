import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddTaskComponent } from './add-task/add-task.component';
import { TasksComponent } from './tasks/tasks.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: '/app-tasks'},
  { path: 'app-add-task', component: AddTaskComponent },
  { path: 'app-tasks', component: TasksComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
